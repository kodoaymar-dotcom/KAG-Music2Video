# Construire KAG Music2Video depuis un téléphone Android

Cette méthode utilise GitHub Actions : le téléphone sert uniquement à envoyer le projet et télécharger l'APK compilé. Aucun ordinateur n'est nécessaire.

## 1. Créer un dépôt GitHub

Depuis Chrome sur Android, ouvre GitHub, connecte-toi, puis crée un nouveau dépôt privé ou public, par exemple `KAG-Music2Video`.

## 2. Envoyer le ZIP

Dans le dépôt : `Add file` → `Upload files`, puis envoie `KAG_Music2Video_Android.zip` à la racine du dépôt.

## 3. Ajouter le workflow

Crée le dossier `.github/workflows` et le fichier `build-apk.yml`. Le contenu recommandé est fourni dans ce projet sous `.github/workflows/build-apk.yml`.

Si tu utilises le workflow fourni ici, il décompresse automatiquement le ZIP, installe Java 17 et Gradle 8.10.2, puis construit l'APK debug.

## 4. Lancer la compilation

Ouvre l'onglet `Actions`, sélectionne `Build KAG Music2Video APK`, puis `Run workflow`.

Attends la fin du job. Dans `Artifacts`, télécharge `KAG-Music2Video-debug`.

## 5. Installer sur le téléphone

Décompresse l'artifact si nécessaire, ouvre `app-debug.apk`, puis autorise l'installation depuis cette source si Android le demande.

## Important

Cet APK est une build de test installable. Pour Google Play, il faudra ensuite une build release signée avec ta clé d'upload et la configuration Play App Signing.

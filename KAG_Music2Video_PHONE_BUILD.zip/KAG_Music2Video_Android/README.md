# KAG Music2Video — Android

Projet Android natif Kotlin + Jetpack Compose avec une base d'architecture séparant :
- Domain : modèles et contrat Repository
- Data : Room/DAO/Repository
- Presentation : ViewModel + états UI
- UI : écrans Compose et navigation locale

## Ouvrir
Importer le dossier dans Android Studio récent et laisser Gradle synchroniser.

## Parcours déjà fonctionnel
- Accueil
- Recherche
- Explorer
- Import d'un fichier audio depuis le téléphone
- Persistance locale des créations avec Room
- Bibliothèque Tout / Vidéos / Audios
- Profil
- Interface mobile sombre KAG Music2Video

## Ce qui n'est volontairement pas simulé
La conversion audio → vidéo n'est pas prétendue fonctionnelle dans cette base. Le projet laisse la couche de rendu vidéo isolée afin de brancher ensuite un moteur réel (local ou serveur) sans refaire l'interface.

## Étape production recommandée
1. Ajouter un module `renderer` avec une interface `VideoRenderer`.
2. Brancher un moteur vidéo adapté au cahier des charges.
3. Ajouter authentification/cloud si nécessaire.
4. Ajouter stockage objet et API backend.
5. Ajouter tests unitaires, tests UI et pipeline CI.
6. Préparer signature, icône, privacy policy et publication Google Play.

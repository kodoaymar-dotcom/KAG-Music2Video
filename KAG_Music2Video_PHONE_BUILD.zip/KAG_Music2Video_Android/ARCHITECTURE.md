# Architecture cible

app -> presentation/domain -> data
             |
             +-> renderer (local Media3)
             +-> cloud (API + object storage, à brancher)

`VideoRenderer` est le point d'extension principal. Le renderer actuel produit un MP4 vertical avec une identité visuelle KAG et la piste audio importée. Une future version peut remplacer `Media3VideoRenderer` par un moteur de scènes synchronisées sans changer les écrans.

Pour une génération IA lourde, le bon choix est de déplacer le rendu vers un worker backend : l'app envoie l'audio + paramètres, reçoit un jobId, suit la progression, puis télécharge une URL signée. Le rendu local reste utile pour les créations simples et hors connexion.

package com.kag.music2video.renderer

import android.net.Uri
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class RenderRequestTest {
    @Test fun defaultsAreVertical1080x1920() {
        val r = RenderRequest(Uri.parse("content://audio"), File("out.mp4"))
        assertEquals(1080, r.width)
        assertEquals(1920, r.height)
        assertEquals(30, r.frameRate)
    }
}

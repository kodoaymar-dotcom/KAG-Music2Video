package com.kag.music2video.renderer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * First production renderer: creates a vertical MP4 from an audio track and a generated visual.
 * The renderer is deliberately isolated so a future AI/scene renderer can replace it without
 * changing the app UI or domain layer.
 */
class Media3VideoRenderer(private val context: Context) : VideoRenderer {
    @Volatile private var activeTransformer: Transformer? = null

    override suspend fun render(request: RenderRequest): RenderResult {
        return try {
            val durationMs = readDuration(request.audioUri)
            require(durationMs > 0) { "Impossible de déterminer la durée de l'audio." }
            val image = createBackground(request.width, request.height, request.title)
            val imageItem = MediaItem.Builder()
                .setUri(Uri.fromFile(image))
                .setImageDurationMs(durationMs)
                .build()
            val visual = EditedMediaItem.Builder(imageItem)
                .setFrameRate(request.frameRate)
                .build()
            val audio = EditedMediaItem.Builder(MediaItem.fromUri(request.audioUri)).build()

            val videoSequence = EditedMediaItemSequence(listOf(visual))
            val audioSequence = EditedMediaItemSequence.withAudioFrom(listOf(audio))
            val composition = Composition.Builder(videoSequence, audioSequence).build()

            request.outputFile.parentFile?.mkdirs()
            suspendCancellableCoroutine { continuation ->
                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: androidx.media3.transformer.ExportResult) {
                        activeTransformer = null
                        if (continuation.isActive) continuation.resume(RenderResult.Success(request.outputFile))
                    }
                    override fun onError(composition: Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                        activeTransformer = null
                        if (continuation.isActive) continuation.resume(RenderResult.Failure(exportException))
                    }
                }
                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(listener)
                    .build()
                activeTransformer = transformer
                continuation.invokeOnCancellation { transformer.cancel() }
                transformer.start(composition, request.outputFile.absolutePath)
            }
        } catch (t: Throwable) {
            RenderResult.Failure(t)
        }
    }

    override fun cancel() { activeTransformer?.cancel() }

    private fun readDuration(uri: Uri): Long {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { retriever.release() }
    }

    private fun createBackground(width: Int, height: Int, title: String): File {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.rgb(8, 11, 16))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = android.graphics.Color.rgb(255, 179, 0)
        paint.textSize = width * 0.075f
        paint.isFakeBoldText = true
        canvas.drawText("KAG", width * .08f, height * .44f, paint)
        paint.color = android.graphics.Color.WHITE
        paint.textSize = width * 0.045f
        canvas.drawText(title.take(32), width * .08f, height * .50f, paint)
        paint.color = android.graphics.Color.argb(160, 255, 179, 0)
        canvas.drawCircle(width * .82f, height * .78f, width * .20f, paint)
        val file = File(context.cacheDir, "kag_visual_${System.currentTimeMillis()}.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }
}

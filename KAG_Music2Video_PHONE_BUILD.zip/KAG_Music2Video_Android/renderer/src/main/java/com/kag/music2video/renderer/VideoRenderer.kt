package com.kag.music2video.renderer

import android.net.Uri
import java.io.File

interface VideoRenderer {
    suspend fun render(request: RenderRequest): RenderResult
    fun cancel()
}

data class RenderRequest(
    val audioUri: Uri,
    val outputFile: File,
    val width: Int = 1080,
    val height: Int = 1920,
    val frameRate: Int = 30,
    val title: String = "KAG Music2Video"
)

sealed interface RenderResult {
    data class Success(val file: File) : RenderResult
    data class Failure(val error: Throwable) : RenderResult
    data object Cancelled : RenderResult
}

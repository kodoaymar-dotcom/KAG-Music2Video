# KAG API

API Fastify + PostgreSQL + stockage objet S3-compatible.

## Endpoints
- `POST /v1/auth/register`
- `POST /v1/auth/login`
- `POST /v1/uploads/presign`
- `GET /v1/creations`
- `POST /v1/creations`
- `GET /v1/objects/download`
- `GET /health`

## Local
`docker compose up --build`

Avant production : TLS/reverse proxy, migrations, rotation des secrets, rate limiting, vérification e-mail, récupération de mot de passe, logs structurés et monitoring.

import Fastify from 'fastify';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { z } from 'zod';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import crypto from 'node:crypto';

const env = z.object({
  PORT: z.coerce.number().default(8080), DATABASE_URL: z.string(), JWT_SECRET: z.string().min(32),
  S3_ENDPOINT: z.string(), S3_REGION: z.string().default('us-east-1'), S3_BUCKET: z.string(),
  S3_ACCESS_KEY: z.string(), S3_SECRET_KEY: z.string()
}).parse(process.env);

const app = Fastify({ logger: true });
const pool = new pg.Pool({ connectionString: env.DATABASE_URL });
const s3 = new S3Client({ endpoint: env.S3_ENDPOINT, region: env.S3_REGION, forcePathStyle: true,
  credentials: { accessKeyId: env.S3_ACCESS_KEY, secretAccessKey: env.S3_SECRET_KEY } });
const secret = new TextEncoder().encode(env.JWT_SECRET);

async function sign(userId: string) {
  return new SignJWT({ sub: userId }).setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('7d').sign(secret);
}
async function auth(req: any, reply: any) {
  const h = req.headers.authorization as string | undefined;
  if (!h?.startsWith('Bearer ')) return reply.code(401).send({ error: 'unauthorized' });
  try { req.userId = (await jwtVerify(h.slice(7), secret)).payload.sub; } catch { return reply.code(401).send({ error: 'unauthorized' }); }
}

app.get('/health', async () => ({ ok: true, service: 'kag-api' }));
app.post('/v1/auth/register', async (req, reply) => {
  const body = z.object({ email: z.string().email(), password: z.string().min(8) }).parse(req.body);
  const hash = await bcrypt.hash(body.password, 12);
  try {
    const r = await pool.query('insert into users(email,password_hash) values($1,$2) returning id,email', [body.email.toLowerCase(), hash]);
    return reply.code(201).send({ user: r.rows[0], token: await sign(r.rows[0].id) });
  } catch { return reply.code(409).send({ error: 'email_already_used' }); }
});
app.post('/v1/auth/login', async (req, reply) => {
  const body = z.object({ email: z.string().email(), password: z.string() }).parse(req.body);
  const r = await pool.query('select id,email,password_hash from users where email=$1', [body.email.toLowerCase()]);
  if (!r.rowCount || !(await bcrypt.compare(body.password, r.rows[0].password_hash))) return reply.code(401).send({ error: 'invalid_credentials' });
  return { user: { id: r.rows[0].id, email: r.rows[0].email }, token: await sign(r.rows[0].id) };
});
app.post('/v1/uploads/presign', { preHandler: auth }, async (req: any) => {
  const body = z.object({ filename: z.string().min(1), contentType: z.string().min(1) }).parse(req.body);
  const key = `${req.userId}/${crypto.randomUUID()}-${body.filename.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
  const command = new PutObjectCommand({ Bucket: env.S3_BUCKET, Key: key, ContentType: body.contentType });
  return { key, uploadUrl: await getSignedUrl(s3, command, { expiresIn: 900 }) };
});
app.get('/v1/creations', { preHandler: auth }, async (req: any) => {
  const r = await pool.query('select id,title,type,status,source_key,output_key,created_at from creations where user_id=$1 order by created_at desc', [req.userId]);
  return { items: r.rows };
});
app.post('/v1/creations', { preHandler: auth }, async (req: any, reply) => {
  const body = z.object({ title: z.string().min(1).max(120), type: z.enum(['AUDIO','VIDEO']), sourceKey: z.string().optional(), outputKey: z.string().optional() }).parse(req.body);
  const r = await pool.query('insert into creations(user_id,title,type,source_key,output_key) values($1,$2,$3,$4,$5) returning *', [req.userId, body.title, body.type, body.sourceKey ?? null, body.outputKey ?? null]);
  return reply.code(201).send(r.rows[0]);
});
app.get('/v1/objects/download', { preHandler: auth }, async (req: any, reply) => {
  const q = z.object({ key: z.string().min(1) }).parse(req.query);
  if (!q.key.startsWith(`${req.userId}/`)) return reply.code(403).send({ error: 'forbidden' });
  const url = await getSignedUrl(s3, new GetObjectCommand({ Bucket: env.S3_BUCKET, Key: q.key }), { expiresIn: 900 });
  return { url };
});

app.listen({ port: env.PORT, host: '0.0.0.0' }).catch(err => { app.log.error(err); process.exit(1); });

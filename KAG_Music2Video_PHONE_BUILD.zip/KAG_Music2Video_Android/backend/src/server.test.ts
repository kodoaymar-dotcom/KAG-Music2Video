import { describe, expect, it } from 'vitest';
describe('KAG API contract', () => {
  it('uses versioned API paths', () => expect('/v1/auth/login'.startsWith('/v1/')).toBe(true));
});

# Cloud / Auth / Storage

Le projet contient maintenant un backend de référence : Fastify + PostgreSQL + stockage objet S3-compatible.

L'application Android contient aussi un contrat Retrofit `CloudApi` pour brancher l'authentification et la synchronisation des créations.

## En production
- Remplacer l'URL locale par l'URL HTTPS de l'API.
- Ajouter un intercepteur OkHttp pour le Bearer token.
- Stocker le token dans Android Keystore/DataStore sécurisé.
- Utiliser des URLs présignées pour les gros fichiers.
- Ne jamais mettre les clés S3 dans l'application Android.
- Faire le rendu lourd côté serveur si les scènes deviennent IA/3D ; conserver Media3 pour les exports simples/local/offline.

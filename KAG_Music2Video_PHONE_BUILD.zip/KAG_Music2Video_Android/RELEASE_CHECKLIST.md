# KAG Music2Video — checklist production Google Play

## Technique
- [x] Android natif Kotlin/Compose
- [x] Module `renderer` isolé
- [x] Media3 Transformer pour export MP4
- [x] Room pour persistance locale
- [x] Tests unitaires de base
- [x] Smoke test Compose
- [x] Pipeline GitHub Actions
- [x] targetSdk 36
- [x] Préparation R8/minification

## Cloud à brancher avant production
- [ ] Choisir le fournisseur (Firebase/Supabase/AWS/etc.)
- [ ] Authentification réelle
- [ ] API HTTPS
- [ ] Stockage objet privé
- [ ] URLs signées pour upload/download
- [ ] Suppression de compte et données
- [ ] Limites de taille et quotas
- [ ] Monitoring et crash reporting

## Signature
- [ ] Générer une clé d'importation RSA 2048+ ou utiliser une clé existante
- [ ] Conserver le keystore hors du dépôt
- [ ] Activer Play App Signing
- [ ] Configurer `signing.properties` uniquement sur la machine/CI sécurisée

## Play Console
- [ ] Compte développeur Google Play
- [ ] Nom, icône, captures d'écran, description
- [ ] URL de politique de confidentialité publique
- [ ] Formulaire Data safety
- [ ] Classification du contenu
- [ ] Déclaration des publicités si applicable
- [ ] Déclaration des permissions sensibles si applicable
- [ ] Adresse/coordonnées éditeur
- [ ] Tests internes puis fermés puis production
- [ ] AAB signé en release

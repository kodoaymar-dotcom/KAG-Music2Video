# Politique de confidentialité — KAG Music2Video

**Dernière mise à jour : 11 septembre 2026**

KAG Music2Video est une application destinée à créer et gérer des contenus vidéo à partir de contenus musicaux fournis par l'utilisateur.

## Données traitées
Selon les fonctionnalités activées dans la version publiée, l'application peut traiter :
- les fichiers audio ou vidéo sélectionnés par l'utilisateur ;
- les informations nécessaires à un compte utilisateur, si l'authentification cloud est activée ;
- les métadonnées des créations (titre, type, date de création) ;
- les journaux techniques nécessaires au fonctionnement et à la sécurité.

## Utilisation
Les données sont utilisées pour importer, transformer, enregistrer, afficher et partager les créations demandées par l'utilisateur, ainsi que pour assurer le fonctionnement et la sécurité du service.

## Stockage cloud
Une version cloud peut stocker les créations et métadonnées sur une infrastructure sécurisée. Les fournisseurs exacts et les catégories de données doivent être indiqués dans la version publiée avant activation du cloud.

## Suppression
Si un compte est proposé, l'utilisateur pourra demander sa suppression et la suppression des données associées via le mécanisme prévu dans l'application et le service.

## Partage
KAG Music2Video ne doit pas vendre les données personnelles des utilisateurs. Les données ne sont partagées avec des prestataires que lorsque cela est nécessaire au fonctionnement du service, à la sécurité, au stockage ou au traitement demandé par l'utilisateur, conformément à la politique publiée.

## Contenus musicaux
L'utilisateur reste responsable de disposer des droits nécessaires pour les fichiers musicaux importés et les contenus utilisés dans ses créations.

## Contact
Avant publication, remplacer cette section par les coordonnées réelles de l'éditeur : nom légal, adresse e-mail de contact et adresse du site/politique de confidentialité.

> Cette politique est un modèle de préparation technique et ne remplace pas une validation juridique. Elle doit être ajustée aux services réellement activés et aux données effectivement collectées.

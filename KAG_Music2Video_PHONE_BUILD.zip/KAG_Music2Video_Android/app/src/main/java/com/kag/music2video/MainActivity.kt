package com.kag.music2video

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.kag.music2video.renderer.Media3VideoRenderer
import com.kag.music2video.renderer.RenderRequest
import com.kag.music2video.renderer.RenderResult

// ---------- Domain ----------
enum class CreationType { AUDIO, VIDEO }

data class Creation(
    val id: Long,
    val title: String,
    val artist: String,
    val type: CreationType,
    val uri: String? = null
)

interface CreationRepository {
    fun observeCreations(): Flow<List<Creation>>
    suspend fun add(creation: Creation)
}

// ---------- Data ----------
@Entity(tableName = "creations")
data class CreationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val artist: String,
    val type: String,
    val uri: String?
)

@Dao
interface CreationDao {
    @Query("SELECT * FROM creations ORDER BY id DESC")
    fun observeAll(): Flow<List<CreationEntity>>

    @Insert
    suspend fun insert(item: CreationEntity)
}

@Database(entities = [CreationEntity::class], version = 1, exportSchema = false)
abstract class KAGDatabase : RoomDatabase() {
    abstract fun creationDao(): CreationDao
}

class RoomCreationRepository(private val dao: CreationDao) : CreationRepository {
    override fun observeCreations(): Flow<List<Creation>> =
        dao.observeAll().map { list ->
            list.map {
                Creation(it.id, it.title, it.artist,
                    if (it.type == "VIDEO") CreationType.VIDEO else CreationType.AUDIO, it.uri)
            }
        }

    override suspend fun add(creation: Creation) {
        dao.insert(CreationEntity(
            title = creation.title,
            artist = creation.artist,
            type = creation.type.name,
            uri = creation.uri
        ))
    }
}

// ---------- Export / Share ----------
object VideoExportManager {
    fun exportToGallery(context: Context, source: File, title: String): Uri? {
        if (!source.exists()) return null
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "KAG_${sanitize(title)}_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KAG Music2Video")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
                try {
                    resolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    uri
                } catch (t: Throwable) {
                    resolver.delete(uri, null, null)
                    throw t
                }
            } else {
                val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "KAG Music2Video")
                dir.mkdirs()
                val dest = File(dir, "KAG_${sanitize(title)}_${System.currentTimeMillis()}.mp4")
                source.inputStream().use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
                android.media.MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf("video/mp4"), null)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", dest)
            }
        } catch (_: Throwable) { null }
    }

    fun share(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Partager la vidéo KAG"))
    }

    private fun sanitize(value: String): String = value.replace(Regex("[^A-Za-z0-9À-ÿ _-]"), "").trim().take(40).ifBlank { "video" }
}

// ---------- Presentation ----------
data class UiState(
    val creations: List<Creation> = emptyList(),
    val search: String = "",
    val selectedTab: Int = 0
)

class MainViewModel(private val repository: CreationRepository, private val renderer: Media3VideoRenderer, private val outputDir: File, private val context: Context) : ViewModel() {
    private val search = MutableStateFlow("")
    private val tab = MutableStateFlow(0)

    val state: StateFlow<UiState> =
        combine(repository.observeCreations(), search, tab) { creations, q, t ->
            UiState(
                creations = creations.filter {
                    q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true)
                },
                search = q,
                selectedTab = t
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    fun search(value: String) { search.value = value }
    fun tab(value: Int) { tab.value = value }

    fun importAudio(uri: Uri, title: String) {
        viewModelScope.launch {
            repository.add(Creation(0, title, "Fichier importé", CreationType.AUDIO, uri.toString()))
        }
    }

    fun renderVideo(uri: Uri, title: String) {
        viewModelScope.launch {
            val output = File(outputDir, "KAG_${System.currentTimeMillis()}.mp4")
            when (val result = renderer.render(RenderRequest(uri, output, title = title))) {
                is RenderResult.Success -> {
                    val exported = VideoExportManager.exportToGallery(context, result.file, title)
                    if (exported != null) {
                        repository.add(Creation(0, title, "KAG", CreationType.VIDEO, exported.toString()))
                    }
                }
                else -> Unit
            }
        }
    }

    fun addDemoVideo() {
        viewModelScope.launch {
            repository.add(Creation(0, "Nouvelle création", "KAG", CreationType.VIDEO))
        }
    }
}

// ---------- UI ----------
private val Bg = Color(0xFF080B10)
private val Card = Color(0xFF151A23)
private val Accent = Color(0xFFFFB300)
private val Muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainViewModel> {
        object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val db = androidx.room.Room.databaseBuilder(
                    applicationContext, KAGDatabase::class.java, "kag.db"
                ).build()
                return MainViewModel(
                    RoomCreationRepository(db.creationDao()),
                    Media3VideoRenderer(applicationContext),
                    applicationContext.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
                        ?: applicationContext.filesDir,
                    applicationContext
                ) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KAGApp(vm) }
    }
}

@Composable
fun KAGApp(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    var screen by remember { mutableStateOf("home") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize()) {
                    if (screen != "home") Spacer(Modifier.height(18.dp))
                    when (screen) {
                        "home" -> HomeScreen(
                            state, vm,
                            onCreate = { screen = "create" },
                            onExplore = { screen = "explore" }
                        )
                        "explore" -> ExploreScreen(state, vm, onBack = { screen = "home" })
                        "create" -> CreateScreen(vm, onBack = { screen = "home"; vm.tab(0) },
                            onLibrary = { screen = "library" })
                        "library" -> LibraryScreen(state, vm, onBack = { screen = "home" })
                        "profile" -> ProfileScreen(onLibrary = { screen = "library" })
                    }
                }

                BottomBar(screen,
                    onHome = { screen = "home" },
                    onExplore = { screen = "explore" },
                    onCreate = { screen = "create" },
                    onLibrary = { screen = "library" },
                    onProfile = { screen = "profile" }
                )
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("KAG", fontSize = MaterialTheme.typography.headlineMedium.fontSize,
            fontWeight = FontWeight.Black)
        Text("Music2Video", color = Muted, modifier = Modifier.padding(start = 7.dp))
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.NotificationsNone, null)
    }
}

@Composable
fun HomeScreen(state: UiState, vm: MainViewModel, onCreate: () -> Unit, onExplore: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 90.dp)) {
        Header()
        Text("Bonjour,", color = Muted, modifier = Modifier.padding(horizontal = 20.dp))
        Text("Crée, écoute, partage ta musique !", style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 6.dp, 20.dp, 16.dp))
        SearchField(state.search, vm::search)
        Hero(onCreate)
        Row(Modifier.fillMaxWidth().padding(20.dp, 24.dp, 20.dp, 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Genres populaires", fontWeight = FontWeight.Bold)
            Text("Voir tout", color = Accent, modifier = Modifier.clickable(onClick = onExplore))
        }
        val genres = listOf("Afrobeat","Gospel","Rap","Reggae","R&B","Pop")
        LazyVerticalGrid(GridCells.Fixed(3), modifier = Modifier.height(190.dp).padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            userScrollEnabled = false) {
            items(genres) { GenreCard(it) }
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        placeholder = { Text("Rechercher une chanson, un artiste...") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        singleLine = true, shape = RoundedCornerShape(28.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Card, focusedContainerColor = Card,
            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Accent
        ))
}

@Composable
fun Hero(onCreate: () -> Unit) {
    Box(Modifier.padding(20.dp).fillMaxWidth().height(170.dp)
        .clip(RoundedCornerShape(22.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF252A33), Color(0xFF7A3027), Color(0xFFD65A15))))) {
        Column(Modifier.padding(22.dp)) {
            Text("Transforme ta\nmusique en vidéo", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Accent),
                modifier = Modifier.padding(top = 17.dp)) { Text("Créer maintenant", color = Color.Black) }
        }
        Text("♫", fontSize = 78.sp, color = Color.White.copy(.35f),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 22.dp))
    }
}

@Composable fun GenreCard(name: String) {
    Box(Modifier.fillMaxWidth().height(85.dp).clip(RoundedCornerShape(14.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF4B2170), Color(0xFF9C35D0)))),
        contentAlignment = Alignment.BottomStart) {
        Text(name, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp))
    }
}

@Composable
fun CreateScreen(vm: MainViewModel, onBack: () -> Unit, onLibrary: () -> Unit) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val title = it.lastPathSegment?.substringAfterLast('/') ?: "Audio importé"
            vm.importAudio(it, title)
            vm.renderVideo(it, title)
            onLibrary()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp, 0.dp, 20.dp, 100.dp)) {
        ScreenTitle("Créer une vidéo", onBack)
        CreateOption("♫","À partir de ma musique","Choisis un son de ta bibliothèque") { onLibrary() }
        CreateOption("☁","À partir d'un fichier audio","Importe un fichier depuis ton téléphone") {
            launcher.launch(arrayOf("audio/*"))
        }
        CreateOption("≋","Par genre","Découvre des sons par style musical") {}
        CreateOption("♙","Par artiste","Explore les titres des artistes préférés") {}
        Spacer(Modifier.height(18.dp))
        Text("Le rendu vidéo sera exécuté par le moteur de rendu connecté à cette couche.",
            color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun CreateOption(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)).background(Accent),
                contentAlignment = Alignment.Center) { Text(icon, color = Color.Black, fontSize = 22.sp) }
            Column(Modifier.weight(1f).padding(start = 13.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp))
            }
            Text("›", fontSize = 28.sp, color = Muted)
        }
    }
}

@Composable
fun ExploreScreen(state: UiState, vm: MainViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp, 0.dp, 20.dp, 100.dp)) {
        ScreenTitle("Explorer", onBack)
        SearchField(state.search, vm::search)
        val items = state.creations
        if (items.isEmpty()) Text("Aucun résultat", color = Muted, modifier = Modifier.padding(10.dp))
        items.forEach { CreationRow(it) }
    }
}

@Composable
fun LibraryScreen(state: UiState, vm: MainViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp, 0.dp, 20.dp, 100.dp)) {
        ScreenTitle("Mes créations", onBack)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tout", "Vidéos", "Audios").forEachIndexed { i, label ->
                FilterChip(selected = state.selectedTab == i, onClick = { vm.tab(i) }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(15.dp))
        val list = when(state.selectedTab) {
            1 -> state.creations.filter { it.type == CreationType.VIDEO }
            2 -> state.creations.filter { it.type == CreationType.AUDIO }
            else -> state.creations
        }
        if (list.isEmpty()) Text("Aucune création pour le moment.", color = Muted)
        LazyVerticalGrid(GridCells.Fixed(2), modifier = Modifier.fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { CreationCard(it) }
        }
    }
}

@Composable
fun CreationCard(item: Creation) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(15.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(115.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF3E1D56), Color(0xFFEF7B24)))),
                contentAlignment = Alignment.Center) {
                Text(if (item.type == CreationType.VIDEO) "▶" else "♫", fontSize = 35.sp)
            }
            Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(10.dp, 10.dp, 10.dp, 2.dp))
            Text(item.artist, color = Muted, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 4.dp))
            if (item.type == CreationType.VIDEO && item.uri != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(Uri.parse(item.uri), "video/mp4")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }) }
                    }, modifier = Modifier.weight(1f)) { Text("Lire") }
                    Button(onClick = { VideoExportManager.share(context, Uri.parse(item.uri)) },
                        modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Text("Partager", color = Color.Black)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable fun CreationRow(item: Creation) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Accent),
                contentAlignment = Alignment.Center) { Text("♫", color = Color.Black, fontSize = 22.sp) }
            Column(Modifier.padding(start = 12.dp)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                Text("${item.artist} · ${if(item.type == CreationType.VIDEO) "Vidéo" else "Audio"}", color = Muted)
            }
        }
    }
}

@Composable
fun ProfileScreen(onLibrary: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp, 10.dp, 20.dp, 100.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(60.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Text("K", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            }
            Column(Modifier.padding(start = 13.dp)) {
                Text("KAG", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                Text("Musicien · Créateur", color = Muted)
            }
            Spacer(Modifier.weight(1f)); Icon(Icons.Default.Settings, null)
        }
        Spacer(Modifier.height(25.dp))
        listOf("Mes créations","Mes favoris","Téléchargements","Paramètres","Aide & support").forEachIndexed { i, label ->
            Card(onClick = if(i==0) onLibrary else ({}), colors = CardDefaults.cardColors(containerColor = Card),
                modifier = Modifier.fillMaxWidth().padding(bottom = 1.dp)) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.weight(1f)); Text("›", fontSize = 24.sp, color = Muted)
                }
            }
        }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) {
            Text("Se déconnecter")
        }
    }
}

@Composable fun ScreenTitle(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BottomBar(screen: String, onHome: () -> Unit, onExplore: () -> Unit, onCreate: () -> Unit, onLibrary: () -> Unit, onProfile: () -> Unit) {
    NavigationBar(containerColor = Bg, modifier = Modifier.align(Alignment.BottomCenter)) {
        NavItem("Accueil", Icons.Default.Home, screen=="home", onHome)
        NavItem("Explorer", Icons.Default.Search, screen=="explore", onExplore)
        NavigationBarItem(selected=false, onClick=onCreate, icon={
            Box(Modifier.size(48.dp).clip(CircleShape).background(Accent), contentAlignment=Alignment.Center) {
                Text("+", color=Color.Black, fontSize=28.sp)
            }
        }, label={})
        NavItem("Bibliothèque", Icons.Default.VideoLibrary, screen=="library", onLibrary)
        NavItem("Profil", Icons.Default.Person, screen=="profile", onProfile)
    }
}

@Composable fun NavItem(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, selected:Boolean, onClick:()->Unit) {
    NavigationBarItem(selected=selected,onClick=onClick,icon={Icon(icon,null)},label={Text(label)})
}

package com.kag.music2video.cloud

import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

@Serializable data class AuthRequest(val email: String, val password: String)
@Serializable data class AuthResponse(val token: String, val user: UserDto)
@Serializable data class UserDto(val id: String, val email: String)
@Serializable data class CreationDto(val id: String, val title: String, val type: String, val status: String)
@Serializable data class CreationListDto(val items: List<CreationDto>)

interface CloudApi {
    @POST("v1/auth/register") suspend fun register(@Body request: AuthRequest): AuthResponse
    @POST("v1/auth/login") suspend fun login(@Body request: AuthRequest): AuthResponse
    @GET("v1/creations") suspend fun creations(): CreationListDto
}

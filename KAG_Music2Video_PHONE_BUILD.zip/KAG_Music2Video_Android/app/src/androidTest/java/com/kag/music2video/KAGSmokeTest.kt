package com.kag.music2video

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class KAGSmokeTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun homeScreenShowsKAGBrand() {
        rule.onNodeWithText("KAG").assertIsDisplayed()
        rule.onNodeWithText("Crée, écoute, partage ta musique !").assertIsDisplayed()
    }
}

package com.kag.music2video

import org.junit.Assert.assertEquals
import org.junit.Test

class UiStateTest {
    @Test fun emptyStateStartsWithAllTab() {
        val state = UiState()
        assertEquals(0, state.selectedTab)
        assertEquals("", state.search)
    }
}
